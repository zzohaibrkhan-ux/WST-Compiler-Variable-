# Excel Report Processor

A web application that processes and compiles Excel/CSV files according to specific business rules for Service Details and Training reports.

## Features

- **Drag & Drop Interface**: Easy file upload with support for multiple Excel/CSV files and ZIP folders
- **ZIP File Support**: Automatically extracts and processes Excel/CSV files from ZIP folders
- **Automated Processing**: Processes files according to specific business rules
- **Column Management**: Intelligent column mapping and cleanup (removes columns after "Excluded?")
- **Date Formatting**: Automatic formatting of date columns to MM/DD/YYYY format
- **Real-time Progress Tracking**: Visual feedback during processing steps
- **Error Handling**: Comprehensive error messages and validation
- **Download Results**: Download processed and compiled reports

## Processing Rules

### Service Details Report Processing

1. **Merge Service Type and Planned Duration**: 
   - Concatenates "Service Type" and "Planned Duration" columns
   - Format: `"Service Type - Planned Duration"`
   - Example: `"Standard Parcel - Custom Delivery Van 12ft - 10 hr"`

2. **Filter by Distance Unit**:
   - Keeps only rows where "Distance unit" column contains "miles"
   - Removes all other rows

### Training Weekly Report Processing

1. **Filter by Payment Eligibility**:
   - Removes rows where "DSP Payment Eligible" is "No"

2. **Filter by Duration**:
   - Removes rows where "Total Duration" is "0 hr"

3. **Merge Service Type and Total Duration**:
   - Concatenates "Service Type" and "Total Duration" columns
   - Format: `"Service Type - Total Duration"`
   - Example: `"Training - 8 hr"`

### Report Compilation

- Combines processed Service Details and Training data
- Maps Training data columns to Service Details structure:
  - "Payment Date" → "Date" column (formatted as short date)
  - "Service Type" → "Service Type" column  
  - "Delivery Associate" → "Delivery Associate" column
  - "Total Duration" → "Planned Duration" column
  - Sets "Distance unit" to "miles" for Training data
  - Sets "Excluded?" to "no" for Training data
- **Column Cleanup**: Removes all columns after "Excluded?" column
- **Date Formatting**: Formats all Date columns as MM/DD/YYYY (e.g., "12/17/2025")

## File Requirements

- **Service Details Report**: Must contain "Service Details Report" in the filename
- **Training Weekly Report**: Must contain "Training Weekly Report" in the filename
- **Supported Formats**: .xlsx, .xls, .csv, .zip (ZIP files containing Excel/CSV files)
- **ZIP Files**: Can contain multiple Excel/CSV files; will be automatically extracted

## Required Columns

### Service Details Report
- Service Type
- Planned Duration
- Distance unit

### Training Weekly Report
- DSP Payment Eligible
- Total Duration
- Service Type
- Payment Date
- Delivery Associate

## Usage

1. **Upload Files**: Drag and drop or click to select Excel/CSV files or ZIP folders
2. **Process**: Click "Process Files" to start the automated processing
3. **Monitor**: Watch the progress steps as they complete
4. **Download**: Download the compiled report when processing is complete

### ZIP File Processing

- Upload ZIP files containing multiple Excel/CSV files
- The system automatically extracts and processes all Excel/CSV files within the ZIP
- Files are matched based on filename patterns (Service Details Report, Training Weekly Report)
- Non-Excel/CSV files within ZIP are ignored

## Error Handling

The application provides detailed error messages for:
- Missing required files
- Missing required columns
- Empty files
- Processing failures
- Invalid file formats
- ZIP extraction errors
- Corrupted or invalid ZIP files

## Technical Details

- **Frontend**: Next.js 15 with TypeScript, Tailwind CSS, shadcn/ui, react-dropzone
- **Backend**: Next.js API routes with XLSX for Excel processing and JSZip for ZIP extraction
- **File Processing**: Server-side processing with comprehensive validation
- **ZIP Support**: Automatic extraction of Excel/CSV files from ZIP folders
- **Response Format**: Downloads compiled Excel file (.xlsx format)

## API Endpoints

- `POST /api/process-files`: Process uploaded files (supports Excel, CSV, and ZIP files)
- `GET /api/health`: Health check endpoint

## Development

```bash
# Install dependencies
bun install

# Run development server
bun run dev

# Check code quality
bun run lint
```

The application runs on `http://localhost:3000` in development mode.