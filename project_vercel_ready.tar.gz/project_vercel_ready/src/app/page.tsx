'use client'

import { useState, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Upload, FileText, Download, CheckCircle, AlertCircle, Loader2, Archive } from 'lucide-react'
import { useDropzone } from 'react-dropzone'

interface ProcessingStep {
  id: string
  title: string
  status: 'pending' | 'processing' | 'completed' | 'error'
  description?: string
}

export default function Home() {
  const [files, setFiles] = useState<File[]>([])
  const [processing, setProcessing] = useState(false)
  const [processedFile, setProcessedFile] = useState<string | null>(null)
  const [steps, setSteps] = useState<ProcessingStep[]>([
    { id: '1', title: 'Upload Files', status: 'pending' },
    { id: '2', title: 'Process Service Details Report', status: 'pending' },
    { id: '3', title: 'Process Training Weekly Report', status: 'pending' },
    { id: '4', title: 'Compile Reports', status: 'pending' },
    { id: '5', title: 'Generate Final Report', status: 'pending' }
  ])
  const [error, setError] = useState<string | null>(null)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const validFiles = acceptedFiles.filter(file => 
      file.name.includes('.xlsx') || 
      file.name.includes('.xls') || 
      file.name.includes('.csv') ||
      file.name.includes('.zip')
    )
    setFiles(prev => [...prev, ...validFiles])
    setError(null)
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
      'text/csv': ['.csv'],
      'application/zip': ['.zip'],
      'application/x-zip-compressed': ['.zip']
    },
    multiple: true
  })

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  const updateStepStatus = (stepId: string, status: ProcessingStep['status'], description?: string) => {
    setSteps(prev => prev.map(step => 
      step.id === stepId ? { ...step, status, description } : step
    ))
  }

  const processFiles = async () => {
    if (files.length === 0) {
      setError('Please upload at least one file')
      return
    }

    setProcessing(true)
    setError(null)
    setProcessedFile(null)

    try {
      const formData = new FormData()
      files.forEach(file => {
        formData.append('files', file)
      })

      updateStepStatus('1', 'completed')
      updateStepStatus('2', 'processing', 'Processing Service Details Report...')

      const response = await fetch('/api/process-files', {
        method: 'POST',
        body: formData
      })

      if (!response.ok) {
        throw new Error('Processing failed')
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      setProcessedFile(url)

      updateStepStatus('2', 'completed')
      updateStepStatus('3', 'completed')
      updateStepStatus('4', 'completed')
      updateStepStatus('5', 'completed')

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during processing')
      updateStepStatus('2', 'error', 'Processing failed')
    } finally {
      setProcessing(false)
    }
  }

  const downloadFile = () => {
    if (processedFile) {
      const a = document.createElement('a')
      a.href = processedFile
      a.download = 'compiled-report.xlsx'
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
    }
  }

  const getStepIcon = (status: ProcessingStep['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case 'processing':
        return <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-500" />
      default:
        return <div className="w-5 h-5 border-2 border-gray-300 rounded-full" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Excel Report Processor
          </h1>
          <p className="text-gray-600">
            Upload your Excel/CSV files or ZIP folders to process and compile Service Details and Training reports
          </p>
        </div>

        <div className="grid gap-6">
          {/* File Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Upload Files
              </CardTitle>
              <CardDescription>
                Drag and drop your Excel/CSV files or ZIP folders here. Make sure to include files containing "Service Details Report" and "Training Weekly Report" in their names. ZIP files will be automatically extracted.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                  isDragActive
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <input {...getInputProps()} />
                <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                {isDragActive ? (
                  <p className="text-blue-600">Drop the files here...</p>
                ) : (
                  <div>
                    <p className="text-gray-600 mb-2">
                      Drag & drop Excel/CSV files or ZIP folders here, or click to select files
                    </p>
                    <p className="text-sm text-gray-500">
                      Supports .xlsx, .xls, .csv, and .zip files (ZIP files will be extracted)
                    </p>
                  </div>
                )}
              </div>

              {files.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Uploaded Files:</h4>
                  <div className="space-y-2">
                    {files.map((file, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div className="flex items-center gap-2">
                          {file.name.includes('.zip') ? (
                            <Archive className="w-4 h-4 text-orange-500" />
                          ) : (
                            <FileText className="w-4 h-4 text-blue-500" />
                          )}
                          <span className="text-sm">{file.name}</span>
                          <span className="text-xs text-gray-500">
                            ({(file.size / 1024).toFixed(1)} KB)
                          </span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFile(index)}
                          disabled={processing}
                        >
                          Remove
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Processing Steps */}
          <Card>
            <CardHeader>
              <CardTitle>Processing Steps</CardTitle>
              <CardDescription>
                Track the progress of your file processing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {steps.map((step) => (
                  <div key={step.id} className="flex items-center gap-3">
                    {getStepIcon(step.status)}
                    <div className="flex-1">
                      <div className="font-medium">{step.title}</div>
                      {step.description && (
                        <div className="text-sm text-gray-600">{step.description}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Error Display */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Action Buttons */}
          <div className="flex gap-4 justify-center">
            <Button
              onClick={processFiles}
              disabled={files.length === 0 || processing}
              size="lg"
              className="px-8"
            >
              {processing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Process Files
                </>
              )}
            </Button>

            {processedFile && (
              <Button
                onClick={downloadFile}
                variant="outline"
                size="lg"
                className="px-8"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Result
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}