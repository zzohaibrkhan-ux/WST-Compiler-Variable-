import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    message: 'Excel Report Processor API is running',
    status: 'healthy',
    timestamp: new Date().toISOString(),
    endpoints: {
      'POST /api/process-files': 'Process Excel/CSV files and generate compiled report',
      'GET /api/health': 'Health check endpoint'
    }
  })
}