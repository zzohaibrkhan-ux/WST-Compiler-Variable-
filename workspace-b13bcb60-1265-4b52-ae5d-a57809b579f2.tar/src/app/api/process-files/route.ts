import { NextRequest, NextResponse } from 'next/server'
import * as XLSX from 'xlsx'
import JSZip from 'jszip'

interface ProcessedRow {
  [key: string]: any
}

interface ServiceDetailsRow extends ProcessedRow {
  'Service Type': string
  'Planned Duration': string
  'Distance unit': string
  'Date'?: string
  'Delivery Associate'?: string
  'Excluded?'?: string
}

interface TrainingRow extends ProcessedRow {
  'DSP Payment Eligible': string
  'Total Duration': string
  'Service Type': string
  'Payment Date': string
  'Delivery Associate': string
}

function findWorksheetByName(workbook: XLSX.WorkBook, namePattern: string): XLSX.WorkSheet | null {
  // First try exact match
  for (const sheetName of workbook.SheetNames) {
    if (sheetName.toLowerCase() === namePattern.toLowerCase()) {
      return workbook.Sheets[sheetName]
    }
  }
  
  // Then try partial match
  for (const sheetName of workbook.SheetNames) {
    if (sheetName.toLowerCase().includes(namePattern.toLowerCase())) {
      return workbook.Sheets[sheetName]
    }
  }
  
  return null
}

function findFileByName(files: File[], namePattern: string): File | null {
  return files.find(file => 
    file.name.toLowerCase().includes(namePattern.toLowerCase())
  ) || null
}

async function extractZipFile(zipFile: File): Promise<File[]> {
  try {
    const zip = new JSZip()
    const zipData = await zipFile.arrayBuffer()
    const loadedZip = await zip.loadAsync(zipData)
    
    const extractedFiles: File[] = []
    
    for (const [filename, file] of Object.entries(loadedZip.files)) {
      // Skip directories
      if (file.dir) continue
      
      // Only process Excel/CSV files
      const fileExtension = filename.toLowerCase().split('.').pop()
      if (!['xlsx', 'xls', 'csv'].includes(fileExtension || '')) continue
      
      try {
        const fileData = await file.async('uint8array')
        const blob = new Blob([fileData], { type: getMimeType(fileExtension || '') })
        const extractedFile = new File([blob], filename, { type: getMimeType(fileExtension || '') })
        extractedFiles.push(extractedFile)
      } catch (error) {
        console.warn(`Failed to extract file ${filename}:`, error)
        // Continue with other files even if one fails
      }
    }
    
    return extractedFiles
  } catch (error) {
    throw new Error(`Failed to extract ZIP file ${zipFile.name}: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}

function getMimeType(extension: string): string {
  switch (extension) {
    case 'xlsx':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    case 'xls':
      return 'application/vnd.ms-excel'
    case 'csv':
      return 'text/csv'
    default:
      return 'application/octet-stream'
  }
}

function formatDate(dateValue: any): string {
  if (!dateValue) return ''
  
  try {
    // If it's already a Date object
    if (dateValue instanceof Date) {
      const month = (dateValue.getMonth() + 1).toString().padStart(2, '0')
      const day = dateValue.getDate().toString().padStart(2, '0')
      const year = dateValue.getFullYear()
      return `${month}/${day}/${year}`
    }
    
    // If it's a string, try to parse it
    if (typeof dateValue === 'string') {
      const date = new Date(dateValue)
      if (!isNaN(date.getTime())) {
        const month = (date.getMonth() + 1).toString().padStart(2, '0')
        const day = date.getDate().toString().padStart(2, '0')
        const year = date.getFullYear()
        return `${month}/${day}/${year}`
      }
    }
    
    // If it's a number (Excel date format)
    if (typeof dateValue === 'number') {
      const date = new Date((dateValue - 25569) * 86400 * 1000)
      if (!isNaN(date.getTime())) {
        const month = (date.getMonth() + 1).toString().padStart(2, '0')
        const day = date.getDate().toString().padStart(2, '0')
        const year = date.getFullYear()
        return `${month}/${day}/${year}`
      }
    }
    
    // Return original value if can't format
    return dateValue.toString()
  } catch (error) {
    return dateValue.toString()
  }
}

function removeColumnsAfterExcluded(data: ServiceDetailsRow[]): ServiceDetailsRow[] {
  if (data.length === 0) return data
  
  const firstRow = data[0]
  const columnOrder: string[] = []
  let excludedIndex = -1
  
  // Determine column order and find "Excluded?" index
  for (const key in firstRow) {
    columnOrder.push(key)
    if (key.toLowerCase().includes('excluded')) {
      excludedIndex = columnOrder.length - 1
    }
  }
  
  // If "Excluded?" column found, keep only columns up to and including it
  if (excludedIndex !== -1) {
    const allowedColumns = columnOrder.slice(0, excludedIndex + 1)
    
    return data.map(row => {
      const filteredRow: ServiceDetailsRow = {}
      allowedColumns.forEach(col => {
        if (row[col] !== undefined) {
          filteredRow[col] = row[col]
        }
      })
      return filteredRow
    })
  }
  
  return data
}

function normalizeColumnName(columnName: string): string {
  return columnName.trim().toLowerCase()
}

function findColumnIndex(row: any, possibleNames: string[]): string | null {
  if (!row || typeof row !== 'object') return null
  
  for (const key in row) {
    const normalizedKey = normalizeColumnName(key.toString())
    for (const possibleName of possibleNames) {
      if (normalizedKey === normalizeColumnName(possibleName)) {
        return key
      }
    }
  }
  return null
}

function processServiceDetailsReport(worksheet: XLSX.WorkSheet): ServiceDetailsRow[] {
  try {
    const jsonData = XLSX.utils.sheet_to_json(worksheet) as ServiceDetailsRow[]
    
    if (jsonData.length === 0) {
      throw new Error('Service Details Report is empty')
    }

    // Find column names (handle variations)
    const firstRow = jsonData[0]
    const serviceTypeCol = findColumnIndex(firstRow, ['Service Type', 'ServiceType', 'service type', 'servicetype'])
    const plannedDurationCol = findColumnIndex(firstRow, ['Planned Duration', 'PlannedDuration', 'planned duration', 'plannedduration'])
    const distanceUnitCol = findColumnIndex(firstRow, ['Distance unit', 'Distance unit', 'DistanceUnit', 'distance unit', 'distanceunit'])
    
    if (!serviceTypeCol) {
      throw new Error('Service Type column not found in Service Details Report')
    }
    
    if (!distanceUnitCol) {
      throw new Error('Distance unit column not found in Service Details Report')
    }

    // Step 1: Merge Service Type and Planned Duration
    const mergedData = jsonData.map(row => {
      const serviceType = row[serviceTypeCol] || ''
      const plannedDuration = plannedDurationCol ? (row[plannedDurationCol] || '') : ''
      
      if (serviceType && plannedDuration) {
        // Check if service type already contains the duration
        if (!serviceType.toString().includes(plannedDuration.toString())) {
          row[serviceTypeCol] = `${serviceType} - ${plannedDuration}`
        }
      }
      
      return row
    })
    
    // Step 2: Filter rows where Distance unit is "miles"
    const filteredData = mergedData.filter(row => {
      const distanceUnit = row[distanceUnitCol]
      return distanceUnit && distanceUnit.toString().toLowerCase().includes('miles')
    })
    
    if (filteredData.length === 0) {
      throw new Error('No rows with "miles" distance unit found in Service Details Report')
    }
    
    return filteredData
  } catch (error) {
    throw new Error(`Error processing Service Details Report: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}

function processTrainingWeeklyReport(worksheet: XLSX.WorkSheet): TrainingRow[] {
  try {
    const jsonData = XLSX.utils.sheet_to_json(worksheet) as TrainingRow[]
    
    if (jsonData.length === 0) {
      throw new Error('Training Weekly Report is empty')
    }

    // Find column names (handle variations)
    const firstRow = jsonData[0]
    const paymentEligibleCol = findColumnIndex(firstRow, ['DSP Payment Eligible', 'DSP Payment Eligible', 'DSP PaymentEligible', 'dsp payment eligible'])
    const totalDurationCol = findColumnIndex(firstRow, ['Total Duration', 'TotalDuration', 'total duration', 'totalduration'])
    const serviceTypeCol = findColumnIndex(firstRow, ['Service Type', 'ServiceType', 'service type', 'servicetype'])
    const paymentDateCol = findColumnIndex(firstRow, ['Payment Date', 'PaymentDate', 'payment date', 'paymentdate'])
    const deliveryAssociateCol = findColumnIndex(firstRow, ['Delivery Associate', 'DeliveryAssociate', 'delivery associate', 'deliveryassociate'])
    
    if (!paymentEligibleCol) {
      throw new Error('DSP Payment Eligible column not found in Training Weekly Report')
    }
    
    if (!totalDurationCol) {
      throw new Error('Total Duration column not found in Training Weekly Report')
    }
    
    if (!serviceTypeCol) {
      throw new Error('Service Type column not found in Training Weekly Report')
    }

    // Step 1: Remove rows where DSP Payment Eligible is "No"
    const paymentEligible = jsonData.filter(row => {
      const eligible = row[paymentEligibleCol]
      return eligible && eligible.toString().toLowerCase() !== 'no'
    })
    
    // Step 2: Remove rows where Total Duration is "0 hr"
    const nonZeroDuration = paymentEligible.filter(row => {
      const duration = row[totalDurationCol]
      return duration && duration.toString() !== '0 hr' && duration.toString() !== '0hr' && duration.toString() !== '0'
    })
    
    // Step 3: Merge Service Type and Total Duration
    const mergedData = nonZeroDuration.map(row => {
      const serviceType = row[serviceTypeCol] || ''
      const totalDuration = row[totalDurationCol] || ''
      
      if (serviceType && totalDuration) {
        // Check if service type already contains the duration
        if (!serviceType.toString().includes(totalDuration.toString())) {
          row[serviceTypeCol] = `${serviceType} - ${totalDuration}`
        }
      }
      
      return row
    })
    
    if (mergedData.length === 0) {
      throw new Error('No valid rows found in Training Weekly Report after filtering')
    }
    
    return mergedData
  } catch (error) {
    throw new Error(`Error processing Training Weekly Report: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}

function compileReports(
  serviceData: ServiceDetailsRow[], 
  trainingData: TrainingRow[]
): ServiceDetailsRow[] {
  try {
    // Add training data to service data
    const compiledData = [...serviceData]
    
    trainingData.forEach(trainingRow => {
      const compiledRow: ServiceDetailsRow = {
        ...trainingRow,
        'Distance unit': 'miles',
        'Excluded?': 'no',
        'Date': trainingRow['Payment Date'] || trainingRow['PaymentDate'] || '',
        'Planned Duration': trainingRow['Total Duration'] || trainingRow['TotalDuration'] || ''
      }
      
      compiledData.push(compiledRow)
    })
    
    // Format Date column as short date
    compiledData.forEach(row => {
      if (row['Date']) {
        row['Date'] = formatDate(row['Date'])
      }
    })
    
    // Remove columns after "Excluded?" column
    const finalData = removeColumnsAfterExcluded(compiledData)
    
    return finalData
  } catch (error) {
    throw new Error(`Error compiling reports: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const uploadedFiles = formData.getAll('files') as File[]
    
    if (uploadedFiles.length === 0) {
      return NextResponse.json({ error: 'No files uploaded' }, { status: 400 })
    }

    // Process files: extract ZIP files and collect all Excel/CSV files
    const allFiles: File[] = []
    
    for (const file of uploadedFiles) {
      if (file.name.toLowerCase().includes('.zip')) {
        try {
          const extractedFiles = await extractZipFile(file)
          allFiles.push(...extractedFiles)
          console.log(`Extracted ${extractedFiles.length} files from ${file.name}`)
        } catch (error) {
          console.error(`Failed to extract ZIP file ${file.name}:`, error)
          return NextResponse.json({ 
            error: `Failed to extract ZIP file ${file.name}: ${error instanceof Error ? error.message : 'Unknown error'}` 
          }, { status: 400 })
        }
      } else {
        allFiles.push(file)
      }
    }

    if (allFiles.length === 0) {
      return NextResponse.json({ 
        error: 'No Excel or CSV files found. Please upload Excel/CSV files or ZIP files containing them.' 
      }, { status: 400 })
    }

    // Find the specific files
    const serviceDetailsFile = findFileByName(allFiles, 'Service Details Report')
    const trainingWeeklyFile = findFileByName(allFiles, 'Training Weekly Report')
    
    if (!serviceDetailsFile) {
      return NextResponse.json({ 
        error: 'Service Details Report file not found. Please upload a file containing "Service Details Report" in its name.' 
      }, { status: 400 })
    }
    
    if (!trainingWeeklyFile) {
      return NextResponse.json({ 
        error: 'Training Weekly Report file not found. Please upload a file containing "Training Weekly Report" in its name.' 
      }, { status: 400 })
    }

    // Process Service Details Report
    const serviceDetailsBuffer = await serviceDetailsFile.arrayBuffer()
    const serviceDetailsWorkbook = XLSX.read(serviceDetailsBuffer)
    
    // Try to find the worksheet - if not found, use the first worksheet
    let serviceDetailsWorksheet = findWorksheetByName(serviceDetailsWorkbook, 'Service Details Report')
    if (!serviceDetailsWorksheet && serviceDetailsWorkbook.SheetNames.length > 0) {
      serviceDetailsWorksheet = serviceDetailsWorkbook.Sheets[serviceDetailsWorkbook.SheetNames[0]]
    }
    
    if (!serviceDetailsWorksheet) {
      return NextResponse.json({ error: 'No worksheet found in Service Details Report file' }, { status: 400 })
    }
    
    const processedServiceData = processServiceDetailsReport(serviceDetailsWorksheet)

    // Process Training Weekly Report
    const trainingWeeklyBuffer = await trainingWeeklyFile.arrayBuffer()
    const trainingWeeklyWorkbook = XLSX.read(trainingWeeklyBuffer)
    
    // Try to find the worksheet - if not found, use the first worksheet
    let trainingWeeklyWorksheet = findWorksheetByName(trainingWeeklyWorkbook, 'Training Weekly Report')
    if (!trainingWeeklyWorksheet && trainingWeeklyWorkbook.SheetNames.length > 0) {
      trainingWeeklyWorksheet = trainingWeeklyWorkbook.Sheets[trainingWeeklyWorkbook.SheetNames[0]]
    }
    
    if (!trainingWeeklyWorksheet) {
      return NextResponse.json({ error: 'No worksheet found in Training Weekly Report file' }, { status: 400 })
    }
    
    const processedTrainingData = processTrainingWeeklyReport(trainingWeeklyWorksheet)

    // Compile both reports
    const compiledData = compileReports(processedServiceData, processedTrainingData)

    // Create new workbook with compiled data
    const newWorkbook = XLSX.utils.book_new()
    const newWorksheet = XLSX.utils.json_to_sheet(compiledData)
    XLSX.utils.book_append_sheet(newWorkbook, newWorksheet, 'Compiled Report')

    // Generate file
    const excelBuffer = XLSX.write(newWorkbook, { type: 'buffer', bookType: 'xlsx' })

    return new NextResponse(excelBuffer, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': 'attachment; filename="compiled-report.xlsx"',
      },
    })

  } catch (error) {
    console.error('Processing error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal server error during file processing' },
      { status: 500 }
    )
  }
}